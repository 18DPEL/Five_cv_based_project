import cv2
from keras.models import load_model
import numpy as np

# Load the pre-trained emotion detection model
model = load_model('model_moblenet.h5')

# Start capturing video from webcam
cap = cv2.VideoCapture(0)

# Define the emotions
emotions = ['fear', 'Angry', 'Neutral', 'Happy']

while True:
    # Read the frame from the webcam
    ret, frame = cap.read()

    # Convert the frame to grayscale
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

    # Convert the grayscale image to a color image
    color_frame = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

    # Use Haar cascades to detect faces in the frame
    face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
    faces = face_cascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

    # Process each face in the frame
    for (x, y, w, h) in faces:
        face_roi = cv2.resize(color_frame[y:y+h, x:x+w], (48, 48))
        face_roi = np.expand_dims(face_roi, axis=0)

        # Predict the emotion using the model
        predicted_class = np.argmax(model.predict(face_roi))
        label = emotions[predicted_class]

        # Draw a rectangle around the face and display the emotion label
        cv2.rectangle(color_frame, (x, y), (x+w, y+h), (255, 0, 0), 2)
        cv2.putText(color_frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

    # Display the frame with emotions
    cv2.imshow('Emotion Recorder', color_frame)

    # Exit the loop when 'q' is pressed
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

# Release the video capture and close all windows
cap.release()
cv2.destroyAllWindows()
