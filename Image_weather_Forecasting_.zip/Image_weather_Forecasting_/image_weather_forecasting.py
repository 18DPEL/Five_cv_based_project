# 7e9fb90b0051b6794b3e84a30726baa3
from PIL import Image, ImageDraw, ImageFont
import requests

# API key for OpenWeatherMap (replace with your own)
api_key = '7e9fb90b0051b6794b3e84a30726baa3'

# City for weather forecast
city = 'New York'

# API endpoint for current weather data
url = f'http://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'

# Send request to the API
response = requests.get(url)
data = response.json()

# Parse the API response
if data['cod'] == 200:
    weather_description = data['weather'][0]['description']
    temperature = data['main']['temp']
    humidity = data['main']['humidity']
    wind_speed = data['wind']['speed']

    # Load the background image
    image = Image.open('image/IMG20220923121239.jpg')
    draw = ImageDraw.Draw(image)

    # Font for displaying weather information
    font = ImageFont.truetype('arial.ttf', 20)

    # Overlay weather information on the image
    draw.text((10, 10), f'Weather: {weather_description}', fill='white', font=font)
    draw.text((10, 40), f'Temperature: {temperature} K', fill='white', font=font)
    draw.text((10, 70), f'Humidity: {humidity}%', fill='white', font=font)
    draw.text((10, 100), f'Wind Speed: {wind_speed} m/s', fill='white', font=font)

    # Save the modified image
    image.save('weather_forecast.jpg')
    print('Weather forecast image created successfully.')
else:
    print('Failed to fetch weather data.')

