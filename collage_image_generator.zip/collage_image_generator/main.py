from PIL import Image
import numpy as np

# List of image paths
image_paths = [
    'image/DSC02968.JPG',
    'image/IMG20220923121239.jpg',
    'image/WhatsApp Image 2022-07-22 at 3.09.06 PM (2).jpeg',
    'image/WhatsApp Image 2022-11-14 at 7.23.35 PM.jpeg',
    # 'image/WhatsApp Image 2022-11-14 at 7.25.59 PM.jpeg'
]

# Open and resize images
images = [Image.open(path) for path in image_paths]
min_width = min(image.width for image in images)
min_height = min(image.height for image in images)
resized_images = [image.resize((min_width, min_height)) for image in images]

# Convert images to numpy arrays
image_arrays = [np.array(image) for image in resized_images]

# Determine the grid size
num_images = len(image_arrays)
cols = int(np.ceil(np.sqrt(num_images)))
rows = int(np.ceil(num_images / cols))

# Create a blank canvas for the collage
collage_width = cols * min_width
collage_height = rows * min_height
collage = Image.new('RGB', (collage_width, collage_height))

# Paste images into the collage
for i in range(rows):
    for j in range(cols):
        idx = i * cols + j
        if idx < num_images:
            collage.paste(Image.fromarray(image_arrays[idx]), (j * min_width, i * min_height))

# Save the collage
collage.save("collage.png")
